(function(KoreSDK){

    var KoreSDK=KoreSDK||{};
    var chatConfig=window.KoreSDK.chatConfig; 

    chatConfig.i18n={
        rtlLanguages:['en'],
        availableLanguages:['en','us'],
        defaultLanguage:"en",
        languageStrings:{
            ar: {
                message: "Message...",
                connecting: "Connecting...",
                reconnecting: "Reconnecting...",
                entertosend: "Press Enter to send",
                endofchat: "End of chat log",
                loadinghistory: "Loading chat history...",
                sendText:"Send",
                closeText:"Close",
                expandText:"Expand",
                minimizeText:"Minimize",
                reconnectText:"Reconnect",
                attachmentText:"Attachment"
            }
        }
    }    

    KoreSDK.chatConfig=chatConfig

})(window.KoreSDK);
